# doh-workshop

The Jupyter Notebooks in this repo can be used to find malicious DNS-over-HTTPS traffic with machine learning. 
